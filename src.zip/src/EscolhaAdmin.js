// src/EscolhaAdmin.js

import React from 'react';
import { useNavigate } from 'react-router-dom';

const EscolhaAdmin = () => {
  const navigate = useNavigate();

  return (
    <div style={{ padding: 30 }}>
      <h2>Área do Administrador</h2>
      <p>Escolha o que deseja acessar:</p>
      <div style={{ marginTop: 20 }}>
        <button onClick={() => navigate('/admin')} style={{ marginRight: 10 }}>
          Painel Administrativo (Excel)
        </button>
        <button onClick={() => navigate('/dashboard')}>
          Dashboard de Cliente
        </button>
      </div>
    </div>
  );
};

export default EscolhaAdmin;
