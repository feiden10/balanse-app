// src/VincularEmpresa.js

import React, { useState } from 'react';
import { auth, db } from './firebaseConfig';
import { doc, setDoc } from 'firebase/firestore';
import { useNavigate } from 'react-router-dom';

function VincularEmpresa() {
  const [empresa, setEmpresa] = useState('');
  const [mensagem, setMensagem] = useState('');
  const navigate = useNavigate();

  const salvarEmpresa = async () => {
    try {
      const user = auth.currentUser;
      if (!user) {
        setMensagem('Usuário não está logado.');
        return;
      }

      await setDoc(doc(db, 'usuarios', user.uid), {
        email: user.email,
        empresa
      });

      setMensagem('Empresa vinculada com sucesso!');
      setTimeout(() => navigate('/dashboard'), 1500); // redireciona para dashboard
    } catch (error) {
      console.error('Erro ao salvar empresa:', error);
      setMensagem('Erro ao salvar empresa.');
    }
  };

  return (
    <div style={{ padding: 30 }}>
      <h2>Vincular Empresa</h2>
      <input
        type="text"
        placeholder="Digite o nome da empresa"
        value={empresa}
        onChange={(e) => setEmpresa(e.target.value)}
      />
      <br />
      <button onClick={salvarEmpresa} style={{ marginTop: 10 }}>
        Salvar Empresa
      </button>
      {mensagem && <p style={{ marginTop: 10 }}>{mensagem}</p>}
    </div>
  );
}

export default VincularEmpresa;
