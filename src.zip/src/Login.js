// src/Login.js

import React, { useState } from 'react';
import { auth, db } from './firebaseConfig';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { useNavigate } from 'react-router-dom';

function Login({ setEmpresaLogada }) {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [erro, setErro] = useState('');
  const navigate = useNavigate();

  const fazerLogin = async (e) => {
    e.preventDefault();
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, senha);
      const user = userCredential.user;

      const docRef = doc(db, 'usuarios', user.uid);
      const docSnap = await getDoc(docRef);

      if (docSnap.exists()) {
        const dados = docSnap.data();

        if (dados.admin === true) {
          // Se for admin, redireciona para a tela de opções
          navigate('/painel');
        } else if (dados.empresa) {
          // Se for cliente comum com empresa vinculada
          setEmpresaLogada(dados.empresa);
          navigate('/dashboard');
        } else {
          // Se for cliente sem empresa vinculada
          navigate('/vincular');
        }
      } else {
        setErro('Usuário sem dados cadastrados no Firestore.');
      }

    } catch (error) {
      console.error('Erro no login:', error);
      setErro('E-mail ou senha inválidos.');
    }
  };

  return (
    <div style={{ padding: 30 }}>
      <h2>Login do Cliente</h2>
      <form onSubmit={fazerLogin}>
        <div>
          <label>E-mail:</label><br />
          <input type="email" value={email} onChange={e => setEmail(e.target.value)} required />
        </div>
        <div>
          <label>Senha:</label><br />
          <input type="password" value={senha} onChange={e => setSenha(e.target.value)} required />
        </div>
        {erro && <p style={{ color: 'red' }}>{erro}</p>}
        <button type="submit">Entrar</button>
      </form>
    </div>
  );
}

export default Login;
