// src/App.js

import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Dashboard from './Dashboard';
import DashboardDRE from './DashboardDRE'; // ✅ novo import
import Login from './Login';
import Register from './Register';
import VincularEmpresa from './VincularEmpresa';
import PainelAdmin from './PainelAdmin';
import RotaAdminProtegida from './RotaAdminProtegida';
import EscolhaAdmin from './EscolhaAdmin';

function App() {
  const [empresaLogada, setEmpresaLogada] = useState(null);

  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login setEmpresaLogada={setEmpresaLogada} />} />
        <Route path="/register" element={<Register />} />
        <Route path="/vincular" element={<VincularEmpresa />} />
        <Route
          path="/dashboard"
          element={
            empresaLogada ? (
              <Dashboard empresa={empresaLogada} />
            ) : (
              <Navigate to="/login" />
            )
          }
        />
        <Route
          path="/dre"
          element={
            <RotaAdminProtegida>
              <DashboardDRE />
            </RotaAdminProtegida>
          }
        />
        <Route
          path="/admin"
          element={
            <RotaAdminProtegida>
              <PainelAdmin />
            </RotaAdminProtegida>
          }
        />
        <Route
          path="/painel"
          element={
            <RotaAdminProtegida>
              <EscolhaAdmin />
            </RotaAdminProtegida>
          }
        />
        <Route path="*" element={<Navigate to="/login" />} />
      </Routes>
    </Router>
  );
}

export default App;
