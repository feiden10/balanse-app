import React, { useEffect, useState } from "react";
import { Navigate } from "react-router-dom";
import { onAuthStateChanged } from "firebase/auth";
import { doc, getDoc } from "firebase/firestore";
import { auth, db } from "./firebaseConfig";

const RotaAdminProtegida = ({ children }) => {
  const [carregando, setCarregando] = useState(true);
  const [autorizado, setAutorizado] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        try {
          const docRef = doc(db, "usuarios", user.uid);
          const docSnap = await getDoc(docRef);

          // ✅ Debug: Verifica se o campo admin está sendo lido corretamente
          console.log("Usuário logado:", user.email);
          console.log("Dados do Firestore:", docSnap.exists() ? docSnap.data() : "Documento não encontrado");

          if (docSnap.exists() && docSnap.data().admin === true) {
            setAutorizado(true);
          } else {
            setAutorizado(false);
          }
        } catch (error) {
          console.error("Erro ao verificar permissão de administrador:", error);
          setAutorizado(false);
        }
      } else {
        setAutorizado(false);
      }

      setCarregando(false);
    });

    return () => unsubscribe();
  }, []);

  if (carregando) {
    return <p>Carregando...</p>;
  }

  return autorizado ? children : <Navigate to="/" />;
};

export default RotaAdminProtegida;
