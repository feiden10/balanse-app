// firebaseConfig.js
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage"; // Adicionado para upload de arquivos

const firebaseConfig = {
  apiKey: "AIzaSyCq--sc_0eZqMLtlWQJ5ZOT7WM4-feNOIk",
  authDomain: "balanse-consultoria.firebaseapp.com",
  projectId: "balanse-consultoria",
  storageBucket: "balanse-consultoria.appspot.com", // Corrigido aqui também
  messagingSenderId: "650005319947",
  appId: "1:650005319947:web:d0857c3ba6e440ffc9520e"
};

// Inicializa o Firebase
const app = initializeApp(firebaseConfig);

// Exporta as instâncias do Firebase
const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app); // Exporta storage para uploads

export { app, auth, db, storage };
