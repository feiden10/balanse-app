// src/Register.js

import React, { useState } from 'react';
import { auth, db } from './firebaseConfig';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore';
import { useNavigate } from 'react-router-dom';

function Register() {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [empresa, setEmpresa] = useState('');
  const navigate = useNavigate();

  const handleRegister = async (e) => {
    e.preventDefault();

    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, senha);

      // Salvar nome da empresa associado ao e-mail
      await setDoc(doc(db, 'usuarios', userCredential.user.uid), {
        email,
        empresa
      });

      alert('Cadastro realizado com sucesso!');
      navigate('/login');
    } catch (error) {
      alert(`Erro no cadastro: ${error.message}`);
    }
  };

  return (
    <div style={{ padding: 30 }}>
      <h2>Cadastrar Empresa</h2>
      <form onSubmit={handleRegister}>
        <div>
          <label>Email:</label><br />
          <input type="email" value={email} onChange={e => setEmail(e.target.value)} required />
        </div>
        <div>
          <label>Senha:</label><br />
          <input type="password" value={senha} onChange={e => setSenha(e.target.value)} required />
        </div>
        <div>
          <label>Nome da Empresa:</label><br />
          <input type="text" value={empresa} onChange={e => setEmpresa(e.target.value)} required />
        </div>
        <button type="submit" style={{ marginTop: 10 }}>Cadastrar</button>
      </form>
    </div>
  );
}

export default Register;
