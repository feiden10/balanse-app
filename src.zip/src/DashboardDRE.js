import React, { useState } from 'react';
import * as XLSX from 'xlsx';
import { db } from './firebaseConfig';
import { collection, doc, setDoc } from 'firebase/firestore';

export default function PainelAdmin() {
  const [erros, setErros] = useState([]);
  const [sucesso, setSucesso] = useState(false);

  const colunasObrigatorias = [
    'CONTA', 'DEMONSTRAÇÃO DO RESULTADO', 'EXECUÇÃO', '%', 'ACUMULADO', '%.1',
    'JAN', 'FEV', 'MAR', 'ABR', 'MAI', 'JUN', 'JUL', 'AGO', 'SET', 'OUT', 'NOV', 'DEZ'
  ];

  const padronizarNome = (nome) => nome.trim().toUpperCase().replace(/\s+/g, '');

  const parseValor = (valor) => {
    if (valor === '' || valor === null || valor === undefined) return 0;
    const str = valor.toString().replace(/R\$|\s|\./g, '').replace(',', '.');
    const negativo = valor.toString().includes('-');
    const numero = parseFloat(str);
    return isNaN(numero) ? 0 : negativo ? -Math.abs(numero) : numero;
  };

  const parsePercentual = (valor) => {
    if (valor === '' || valor === null || valor === undefined) return 0;
    const numero = parseFloat(valor);
    return isNaN(numero) ? 0 : numero;
  };

  const handleUpload = async (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();

    reader.onload = async (evt) => {
      const data = new Uint8Array(evt.target.result);
      const workbook = XLSX.read(data, { type: 'array' });
      const worksheet = workbook.Sheets[workbook.SheetNames[0]];
      const json = XLSX.utils.sheet_to_json(worksheet, { defval: '' });

      const colunasPlanilha = Object.keys(json[0]).map(padronizarNome);
      const colunasObrigatoriasPadrao = colunasObrigatorias.map(padronizarNome);
      const faltando = colunasObrigatoriasPadrao.filter(c => !colunasPlanilha.includes(c));

      if (faltando.length > 0) {
        setErros([`Colunas faltando: ${faltando.join(', ')}`]);
        return;
      }

      const dadosTratados = [];
      const errosDetectados = [];

      json.forEach((linha, i) => {
        try {
          const item = {
            conta: linha['CONTA'],
            descricao: linha['DEMONSTRAÇÃO DO RESULTADO'],
            execucao: parseValor(linha['EXECUÇÃO']),
            percentual: parsePercentual(linha['%']),
            acumulado: parseValor(linha['ACUMULADO']),
            percentualAcumulado: parsePercentual(linha['%.1']),
            meses: {
              JAN: parseValor(linha['JAN']),
              FEV: parseValor(linha['FEV']),
              MAR: parseValor(linha['MAR']),
              ABR: parseValor(linha['ABR']),
              MAI: parseValor(linha['MAI']),
              JUN: parseValor(linha['JUN']),
              JUL: parseValor(linha['JUL']),
              AGO: parseValor(linha['AGO']),
              SET: parseValor(linha['SET']),
              OUT: parseValor(linha['OUT']),
              NOV: parseValor(linha['NOV']),
              DEZ: parseValor(linha['DEZ'])
            }
          };
          dadosTratados.push(item);
        } catch (err) {
          errosDetectados.push(`Erro na linha ${i + 2}`);
        }
      });

      if (errosDetectados.length > 0) {
        setErros(errosDetectados);
        return;
      }

      try {
        const empresaRef = doc(collection(db, 'empresas'), 'empresaExemplo');
        await setDoc(empresaRef, { dreDetalhado: dadosTratados }, { merge: true });
        setErros([]);
        setSucesso(true);
      } catch (err) {
        setErros(['Erro ao salvar no Firestore']);
      }
    };

    reader.readAsArrayBuffer(file);
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h2 className="text-xl font-bold mb-4">Painel Administrativo - Upload de DRE</h2>
      <input type="file" accept=".xlsx, .xls" onChange={handleUpload} className="mb-4" />
      {erros.length > 0 && (
        <div className="bg-red-100 text-red-700 p-4 rounded mb-4">
          <h4 className="font-semibold">Erros detectados:</h4>
          <ul className="list-disc ml-6">
            {erros.map((e, i) => <li key={i}>{e}</li>)}
          </ul>
        </div>
      )}
      {sucesso && (
        <div className="bg-green-100 text-green-800 p-4 rounded">
          Upload realizado com sucesso!
        </div>
      )}
      <button onClick={() => setSucesso(false)} className="bg-blue-500 text-white px-4 py-2 rounded mt-4">
        Fechar mensagem
      </button>
    </div>
  );
}
